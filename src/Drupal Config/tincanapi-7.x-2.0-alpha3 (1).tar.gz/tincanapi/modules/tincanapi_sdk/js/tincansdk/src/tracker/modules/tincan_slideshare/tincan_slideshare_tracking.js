(function (exports) {

    var
        Watcher = require('./tincan_slideshare_watcher').Watcher,

        helper = require('../../../helper');

    exports.start = function () {

    };

})(module.exports);
