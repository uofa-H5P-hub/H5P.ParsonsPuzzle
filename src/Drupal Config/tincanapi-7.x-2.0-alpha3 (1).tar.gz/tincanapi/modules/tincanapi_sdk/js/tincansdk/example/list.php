<?php

/**
 * @file
 * List example - Template file.
 */
?>
<html>
    <head>
        <title>A random list</title>
    </head>
    <body>
        <a href="./">Back to index</a>

        <ol>
            <li>One</li>
            <li>Two</li>
        </ol>

        <?php include 'includes/sdk.php'; ?>
    </body>
</html>
