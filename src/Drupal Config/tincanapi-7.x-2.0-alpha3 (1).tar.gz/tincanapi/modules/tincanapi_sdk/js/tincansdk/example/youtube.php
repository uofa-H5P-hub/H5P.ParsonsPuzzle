<?php

/**
 * @file
 * Youtube example - Template file.
 */
?>
<html>
    <head>
        <title>Listen to this song</title>
    </head>
    <body>
        <a href="./">Back to index</a>
        <br />

        <iframe width="560" height="315" src="https://www.youtube.com/embed/R-jGJgKqP00" frameborder="0" allowfullscreen></iframe>

        <?php include 'includes/sdk.php'; ?>
    </body>
</html>
