(function (exports) {

    var
        Statement = require('../../../builder/statement').Statement,

        mediaExtensions = require('../../../tracker/modules/tincan_media/media_extensions');

    exports.Watcher = function (id) {
        var _this = this;

        this.init = function () {

        };

        this.init();
    };

})(module.exports);
